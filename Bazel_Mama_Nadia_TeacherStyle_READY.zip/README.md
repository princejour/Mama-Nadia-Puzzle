# Bazel Mama Nadia APK

مشروع Android WebView جاهز للبناء على GitHub Actions.

الملفات الأساسية موجودة مباشرة في جذر المشروع مثل نسخة تطبيق الأستاذ.

شغّل Actions ثم Build Bazel Mama Nadia APK ثم Run workflow.
